tinymce.addI18n('nl', {
    'YouTube Tooltip'   : "YouTube",
    'YouTube Title'     : "YouTube-video invoegen",
    'Youtube URL'       : 'Video-link',
    'Youtube ID'        : 'http://youtu.be/xxxxxxxx of http://www.youtube.com/watch?v=xxxxxxxx',
    'width'             : 'Breedte',
    'height'            : 'Hoogte',
    'autoplay'          : 'Automatisch afspelen',
    'Related video'     : 'Toon gerelateerde videos',
    'HD video'          : 'Toon in HD-resolutie',
    'cancel'            : 'Cancel',
    'Insert'            : 'Insert'
});
